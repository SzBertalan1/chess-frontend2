# Known issues / ismert problémák:
A Routing HashRouter-rel lett deployolva, hogy GH-Pages-en is jól jelenjen meg!
Egyébként BrowserRouter-rel kell megvalósítani, az App.jsx-ben átírva!
